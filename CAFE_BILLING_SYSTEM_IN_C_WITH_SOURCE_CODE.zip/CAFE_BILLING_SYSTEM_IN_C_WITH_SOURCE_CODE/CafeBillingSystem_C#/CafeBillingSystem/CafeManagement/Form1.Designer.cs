﻿namespace CafeManagement
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtChineseTea = new System.Windows.Forms.TextBox();
            this.txtMilkTea = new System.Windows.Forms.TextBox();
            this.txtAfricanCoffee = new System.Windows.Forms.TextBox();
            this.txtCappu = new System.Windows.Forms.TextBox();
            this.txtValeCoffee = new System.Windows.Forms.TextBox();
            this.txtMocha = new System.Windows.Forms.TextBox();
            this.txtEspresso = new System.Windows.Forms.TextBox();
            this.txtLatte = new System.Windows.Forms.TextBox();
            this.chkChineseTea = new System.Windows.Forms.CheckBox();
            this.chkMilkTea = new System.Windows.Forms.CheckBox();
            this.chkAfricanCoffe = new System.Windows.Forms.CheckBox();
            this.chkCappucino = new System.Windows.Forms.CheckBox();
            this.chkValeCoffee = new System.Windows.Forms.CheckBox();
            this.chkMocha = new System.Windows.Forms.CheckBox();
            this.chkEspresso = new System.Windows.Forms.CheckBox();
            this.chkLatte = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblSvcCharge = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblCakeCost = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblDrinkCost = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtRainbowCake = new System.Windows.Forms.TextBox();
            this.chkRainbowCake = new System.Windows.Forms.CheckBox();
            this.txtCheeseCake = new System.Windows.Forms.TextBox();
            this.chkCoffe = new System.Windows.Forms.CheckBox();
            this.txtKillburnChoco = new System.Windows.Forms.TextBox();
            this.chkCheese = new System.Windows.Forms.CheckBox();
            this.txtLagosChoco = new System.Windows.Forms.TextBox();
            this.chkRedValvet = new System.Windows.Forms.CheckBox();
            this.txtBostonCream = new System.Windows.Forms.TextBox();
            this.txtBlackForestCake = new System.Windows.Forms.TextBox();
            this.chkKilburnChoco = new System.Windows.Forms.CheckBox();
            this.txtRedValvetCake = new System.Windows.Forms.TextBox();
            this.chkBlackForest = new System.Windows.Forms.CheckBox();
            this.txtCoffeCake = new System.Windows.Forms.TextBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.chkBostonCream = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rtfReceipt = new System.Windows.Forms.RichTextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.lblTimer);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(8, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(953, 75);
            this.panel1.TabIndex = 0;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDate.Location = new System.Drawing.Point(882, 60);
            this.lblDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(41, 13);
            this.lblDate.TabIndex = 3;
            this.lblDate.Text = "label6";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTimer.Location = new System.Drawing.Point(11, 62);
            this.lblTimer.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(41, 13);
            this.lblTimer.TabIndex = 2;
            this.lblTimer.Text = "label6";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(11, 5);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 65);
            this.label2.TabIndex = 1;
            this.label2.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(179, -4);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(606, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cafe Billing System";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.txtChineseTea);
            this.panel2.Controls.Add(this.txtMilkTea);
            this.panel2.Controls.Add(this.txtAfricanCoffee);
            this.panel2.Controls.Add(this.txtCappu);
            this.panel2.Controls.Add(this.txtValeCoffee);
            this.panel2.Controls.Add(this.txtMocha);
            this.panel2.Controls.Add(this.txtEspresso);
            this.panel2.Controls.Add(this.txtLatte);
            this.panel2.Controls.Add(this.chkChineseTea);
            this.panel2.Controls.Add(this.chkMilkTea);
            this.panel2.Controls.Add(this.chkAfricanCoffe);
            this.panel2.Controls.Add(this.chkCappucino);
            this.panel2.Controls.Add(this.chkValeCoffee);
            this.panel2.Controls.Add(this.chkMocha);
            this.panel2.Controls.Add(this.chkEspresso);
            this.panel2.Controls.Add(this.chkLatte);
            this.panel2.Location = new System.Drawing.Point(8, 80);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(333, 204);
            this.panel2.TabIndex = 1;
            // 
            // txtChineseTea
            // 
            this.txtChineseTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChineseTea.Location = new System.Drawing.Point(203, 166);
            this.txtChineseTea.Margin = new System.Windows.Forms.Padding(2);
            this.txtChineseTea.Multiline = true;
            this.txtChineseTea.Name = "txtChineseTea";
            this.txtChineseTea.Size = new System.Drawing.Size(79, 25);
            this.txtChineseTea.TabIndex = 4;
            this.txtChineseTea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtChineseTea.Click += new System.EventHandler(this.txtChineseTea_Click);
            // 
            // txtMilkTea
            // 
            this.txtMilkTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMilkTea.Location = new System.Drawing.Point(203, 144);
            this.txtMilkTea.Margin = new System.Windows.Forms.Padding(2);
            this.txtMilkTea.Multiline = true;
            this.txtMilkTea.Name = "txtMilkTea";
            this.txtMilkTea.Size = new System.Drawing.Size(79, 25);
            this.txtMilkTea.TabIndex = 4;
            this.txtMilkTea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMilkTea.Click += new System.EventHandler(this.txtMilkTea_Click);
            // 
            // txtAfricanCoffee
            // 
            this.txtAfricanCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAfricanCoffee.Location = new System.Drawing.Point(203, 120);
            this.txtAfricanCoffee.Margin = new System.Windows.Forms.Padding(2);
            this.txtAfricanCoffee.Multiline = true;
            this.txtAfricanCoffee.Name = "txtAfricanCoffee";
            this.txtAfricanCoffee.Size = new System.Drawing.Size(79, 25);
            this.txtAfricanCoffee.TabIndex = 4;
            this.txtAfricanCoffee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAfricanCoffee.Click += new System.EventHandler(this.txtAfricanCoffee_Click);
            // 
            // txtCappu
            // 
            this.txtCappu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCappu.Location = new System.Drawing.Point(203, 97);
            this.txtCappu.Margin = new System.Windows.Forms.Padding(2);
            this.txtCappu.Multiline = true;
            this.txtCappu.Name = "txtCappu";
            this.txtCappu.Size = new System.Drawing.Size(79, 25);
            this.txtCappu.TabIndex = 4;
            this.txtCappu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCappu.Click += new System.EventHandler(this.txtCappu_Click);
            // 
            // txtValeCoffee
            // 
            this.txtValeCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValeCoffee.Location = new System.Drawing.Point(203, 73);
            this.txtValeCoffee.Margin = new System.Windows.Forms.Padding(2);
            this.txtValeCoffee.Multiline = true;
            this.txtValeCoffee.Name = "txtValeCoffee";
            this.txtValeCoffee.Size = new System.Drawing.Size(79, 25);
            this.txtValeCoffee.TabIndex = 4;
            this.txtValeCoffee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtValeCoffee.Click += new System.EventHandler(this.txtValeCoffee_Click);
            // 
            // txtMocha
            // 
            this.txtMocha.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMocha.Location = new System.Drawing.Point(203, 50);
            this.txtMocha.Margin = new System.Windows.Forms.Padding(2);
            this.txtMocha.Multiline = true;
            this.txtMocha.Name = "txtMocha";
            this.txtMocha.Size = new System.Drawing.Size(79, 25);
            this.txtMocha.TabIndex = 4;
            this.txtMocha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMocha.Click += new System.EventHandler(this.txtMocha_Click);
            // 
            // txtEspresso
            // 
            this.txtEspresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEspresso.Location = new System.Drawing.Point(203, 27);
            this.txtEspresso.Margin = new System.Windows.Forms.Padding(2);
            this.txtEspresso.Multiline = true;
            this.txtEspresso.Name = "txtEspresso";
            this.txtEspresso.Size = new System.Drawing.Size(79, 25);
            this.txtEspresso.TabIndex = 4;
            this.txtEspresso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtEspresso.Click += new System.EventHandler(this.txtEspresso_Click);
            // 
            // txtLatte
            // 
            this.txtLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLatte.Location = new System.Drawing.Point(203, 3);
            this.txtLatte.Margin = new System.Windows.Forms.Padding(2);
            this.txtLatte.Multiline = true;
            this.txtLatte.Name = "txtLatte";
            this.txtLatte.Size = new System.Drawing.Size(79, 25);
            this.txtLatte.TabIndex = 3;
            this.txtLatte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLatte.Click += new System.EventHandler(this.txtLatte_Click);
            // 
            // chkChineseTea
            // 
            this.chkChineseTea.AutoSize = true;
            this.chkChineseTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkChineseTea.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkChineseTea.Location = new System.Drawing.Point(11, 172);
            this.chkChineseTea.Margin = new System.Windows.Forms.Padding(2);
            this.chkChineseTea.Name = "chkChineseTea";
            this.chkChineseTea.Size = new System.Drawing.Size(118, 21);
            this.chkChineseTea.TabIndex = 2;
            this.chkChineseTea.Text = "Chinese Tea";
            this.chkChineseTea.UseVisualStyleBackColor = true;
            this.chkChineseTea.CheckedChanged += new System.EventHandler(this.chkChineseTea_CheckedChanged);
            // 
            // chkMilkTea
            // 
            this.chkMilkTea.AutoSize = true;
            this.chkMilkTea.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMilkTea.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkMilkTea.Location = new System.Drawing.Point(11, 149);
            this.chkMilkTea.Margin = new System.Windows.Forms.Padding(2);
            this.chkMilkTea.Name = "chkMilkTea";
            this.chkMilkTea.Size = new System.Drawing.Size(88, 21);
            this.chkMilkTea.TabIndex = 1;
            this.chkMilkTea.Text = "Milk Tea";
            this.chkMilkTea.UseVisualStyleBackColor = true;
            this.chkMilkTea.CheckedChanged += new System.EventHandler(this.chkMilkTea_CheckedChanged);
            // 
            // chkAfricanCoffe
            // 
            this.chkAfricanCoffe.AutoSize = true;
            this.chkAfricanCoffe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAfricanCoffe.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkAfricanCoffe.Location = new System.Drawing.Point(11, 125);
            this.chkAfricanCoffe.Margin = new System.Windows.Forms.Padding(2);
            this.chkAfricanCoffe.Name = "chkAfricanCoffe";
            this.chkAfricanCoffe.Size = new System.Drawing.Size(111, 21);
            this.chkAfricanCoffe.TabIndex = 1;
            this.chkAfricanCoffe.Text = "Cold Coffee";
            this.chkAfricanCoffe.UseVisualStyleBackColor = true;
            this.chkAfricanCoffe.CheckedChanged += new System.EventHandler(this.chkAfricanCoffe_CheckedChanged);
            // 
            // chkCappucino
            // 
            this.chkCappucino.AutoSize = true;
            this.chkCappucino.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCappucino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkCappucino.Location = new System.Drawing.Point(11, 102);
            this.chkCappucino.Margin = new System.Windows.Forms.Padding(2);
            this.chkCappucino.Name = "chkCappucino";
            this.chkCappucino.Size = new System.Drawing.Size(103, 21);
            this.chkCappucino.TabIndex = 1;
            this.chkCappucino.Text = "Cappucino";
            this.chkCappucino.UseVisualStyleBackColor = true;
            this.chkCappucino.CheckedChanged += new System.EventHandler(this.chkCappucino_CheckedChanged);
            // 
            // chkValeCoffee
            // 
            this.chkValeCoffee.AutoSize = true;
            this.chkValeCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkValeCoffee.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkValeCoffee.Location = new System.Drawing.Point(11, 79);
            this.chkValeCoffee.Margin = new System.Windows.Forms.Padding(2);
            this.chkValeCoffee.Name = "chkValeCoffee";
            this.chkValeCoffee.Size = new System.Drawing.Size(106, 21);
            this.chkValeCoffee.TabIndex = 1;
            this.chkValeCoffee.Text = "ValeCoffee";
            this.chkValeCoffee.UseVisualStyleBackColor = true;
            this.chkValeCoffee.CheckedChanged += new System.EventHandler(this.chkValeCoffee_CheckedChanged);
            // 
            // chkMocha
            // 
            this.chkMocha.AutoSize = true;
            this.chkMocha.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMocha.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkMocha.Location = new System.Drawing.Point(11, 55);
            this.chkMocha.Margin = new System.Windows.Forms.Padding(2);
            this.chkMocha.Name = "chkMocha";
            this.chkMocha.Size = new System.Drawing.Size(74, 21);
            this.chkMocha.TabIndex = 1;
            this.chkMocha.Text = "Mocha";
            this.chkMocha.UseVisualStyleBackColor = true;
            this.chkMocha.CheckedChanged += new System.EventHandler(this.chkMocha_CheckedChanged);
            // 
            // chkEspresso
            // 
            this.chkEspresso.AutoSize = true;
            this.chkEspresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEspresso.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkEspresso.Location = new System.Drawing.Point(11, 32);
            this.chkEspresso.Margin = new System.Windows.Forms.Padding(2);
            this.chkEspresso.Name = "chkEspresso";
            this.chkEspresso.Size = new System.Drawing.Size(94, 21);
            this.chkEspresso.TabIndex = 1;
            this.chkEspresso.Text = "Espresso";
            this.chkEspresso.UseVisualStyleBackColor = true;
            this.chkEspresso.CheckedChanged += new System.EventHandler(this.chkEspresso_CheckedChanged);
            // 
            // chkLatte
            // 
            this.chkLatte.AutoSize = true;
            this.chkLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLatte.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkLatte.Location = new System.Drawing.Point(11, 8);
            this.chkLatte.Margin = new System.Windows.Forms.Padding(2);
            this.chkLatte.Name = "chkLatte";
            this.chkLatte.Size = new System.Drawing.Size(64, 21);
            this.chkLatte.TabIndex = 0;
            this.chkLatte.Text = "Latte";
            this.chkLatte.UseVisualStyleBackColor = true;
            this.chkLatte.CheckedChanged += new System.EventHandler(this.chkLatte_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel3.Controls.Add(this.lblSvcCharge);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.lblCakeCost);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.lblDrinkCost);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(8, 288);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(333, 148);
            this.panel3.TabIndex = 1;
            // 
            // lblSvcCharge
            // 
            this.lblSvcCharge.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSvcCharge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSvcCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSvcCharge.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSvcCharge.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblSvcCharge.Location = new System.Drawing.Point(161, 102);
            this.lblSvcCharge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSvcCharge.Name = "lblSvcCharge";
            this.lblSvcCharge.Size = new System.Drawing.Size(149, 29);
            this.lblSvcCharge.TabIndex = 2;
            this.lblSvcCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(7, 105);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "Service Charge";
            // 
            // lblCakeCost
            // 
            this.lblCakeCost.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCakeCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCakeCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCakeCost.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCakeCost.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblCakeCost.Location = new System.Drawing.Point(161, 69);
            this.lblCakeCost.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCakeCost.Name = "lblCakeCost";
            this.lblCakeCost.Size = new System.Drawing.Size(149, 29);
            this.lblCakeCost.TabIndex = 1;
            this.lblCakeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(7, 72);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 24);
            this.label4.TabIndex = 1;
            this.label4.Text = "Cost of Cakes";
            // 
            // lblDrinkCost
            // 
            this.lblDrinkCost.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDrinkCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDrinkCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrinkCost.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDrinkCost.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblDrinkCost.Location = new System.Drawing.Point(161, 34);
            this.lblDrinkCost.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDrinkCost.Name = "lblDrinkCost";
            this.lblDrinkCost.Size = new System.Drawing.Size(149, 29);
            this.lblDrinkCost.TabIndex = 0;
            this.lblDrinkCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(7, 38);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "Cost of Drinks";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel4.Controls.Add(this.txtRainbowCake);
            this.panel4.Controls.Add(this.chkRainbowCake);
            this.panel4.Controls.Add(this.txtCheeseCake);
            this.panel4.Controls.Add(this.chkCoffe);
            this.panel4.Controls.Add(this.txtKillburnChoco);
            this.panel4.Controls.Add(this.chkCheese);
            this.panel4.Controls.Add(this.txtLagosChoco);
            this.panel4.Controls.Add(this.chkRedValvet);
            this.panel4.Controls.Add(this.txtBostonCream);
            this.panel4.Controls.Add(this.txtBlackForestCake);
            this.panel4.Controls.Add(this.chkKilburnChoco);
            this.panel4.Controls.Add(this.txtRedValvetCake);
            this.panel4.Controls.Add(this.chkBlackForest);
            this.panel4.Controls.Add(this.txtCoffeCake);
            this.panel4.Controls.Add(this.checkBox13);
            this.panel4.Controls.Add(this.chkBostonCream);
            this.panel4.Location = new System.Drawing.Point(345, 80);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(333, 204);
            this.panel4.TabIndex = 1;
            // 
            // txtRainbowCake
            // 
            this.txtRainbowCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRainbowCake.Location = new System.Drawing.Point(206, 166);
            this.txtRainbowCake.Margin = new System.Windows.Forms.Padding(2);
            this.txtRainbowCake.Multiline = true;
            this.txtRainbowCake.Name = "txtRainbowCake";
            this.txtRainbowCake.Size = new System.Drawing.Size(79, 25);
            this.txtRainbowCake.TabIndex = 4;
            this.txtRainbowCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRainbowCake.Click += new System.EventHandler(this.txtRainbowCake_Click);
            // 
            // chkRainbowCake
            // 
            this.chkRainbowCake.AutoSize = true;
            this.chkRainbowCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRainbowCake.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkRainbowCake.Location = new System.Drawing.Point(11, 172);
            this.chkRainbowCake.Margin = new System.Windows.Forms.Padding(2);
            this.chkRainbowCake.Name = "chkRainbowCake";
            this.chkRainbowCake.Size = new System.Drawing.Size(129, 21);
            this.chkRainbowCake.TabIndex = 2;
            this.chkRainbowCake.Text = "Rainbow Cake";
            this.chkRainbowCake.UseVisualStyleBackColor = true;
            this.chkRainbowCake.CheckedChanged += new System.EventHandler(this.chkRainbowCake_CheckedChanged);
            // 
            // txtCheeseCake
            // 
            this.txtCheeseCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheeseCake.Location = new System.Drawing.Point(206, 144);
            this.txtCheeseCake.Margin = new System.Windows.Forms.Padding(2);
            this.txtCheeseCake.Multiline = true;
            this.txtCheeseCake.Name = "txtCheeseCake";
            this.txtCheeseCake.Size = new System.Drawing.Size(79, 25);
            this.txtCheeseCake.TabIndex = 4;
            this.txtCheeseCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCheeseCake.Click += new System.EventHandler(this.txtCheeseCake_Click);
            // 
            // chkCoffe
            // 
            this.chkCoffe.AutoSize = true;
            this.chkCoffe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCoffe.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkCoffe.Location = new System.Drawing.Point(11, 8);
            this.chkCoffe.Margin = new System.Windows.Forms.Padding(2);
            this.chkCoffe.Name = "chkCoffe";
            this.chkCoffe.Size = new System.Drawing.Size(115, 21);
            this.chkCoffe.TabIndex = 0;
            this.chkCoffe.Text = "Coffee Cake";
            this.chkCoffe.UseVisualStyleBackColor = true;
            this.chkCoffe.CheckedChanged += new System.EventHandler(this.chkCoffe_CheckedChanged);
            // 
            // txtKillburnChoco
            // 
            this.txtKillburnChoco.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKillburnChoco.Location = new System.Drawing.Point(206, 120);
            this.txtKillburnChoco.Margin = new System.Windows.Forms.Padding(2);
            this.txtKillburnChoco.Multiline = true;
            this.txtKillburnChoco.Name = "txtKillburnChoco";
            this.txtKillburnChoco.Size = new System.Drawing.Size(79, 25);
            this.txtKillburnChoco.TabIndex = 4;
            this.txtKillburnChoco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtKillburnChoco.Click += new System.EventHandler(this.txtKillburnChoco_Click);
            // 
            // chkCheese
            // 
            this.chkCheese.AutoSize = true;
            this.chkCheese.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCheese.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkCheese.Location = new System.Drawing.Point(11, 149);
            this.chkCheese.Margin = new System.Windows.Forms.Padding(2);
            this.chkCheese.Name = "chkCheese";
            this.chkCheese.Size = new System.Drawing.Size(122, 21);
            this.chkCheese.TabIndex = 1;
            this.chkCheese.Text = "Cheese Cake";
            this.chkCheese.UseVisualStyleBackColor = true;
            this.chkCheese.CheckedChanged += new System.EventHandler(this.chkCheese_CheckedChanged);
            // 
            // txtLagosChoco
            // 
            this.txtLagosChoco.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLagosChoco.Location = new System.Drawing.Point(206, 97);
            this.txtLagosChoco.Margin = new System.Windows.Forms.Padding(2);
            this.txtLagosChoco.Multiline = true;
            this.txtLagosChoco.Name = "txtLagosChoco";
            this.txtLagosChoco.Size = new System.Drawing.Size(79, 25);
            this.txtLagosChoco.TabIndex = 4;
            this.txtLagosChoco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLagosChoco.Click += new System.EventHandler(this.txtLagosChoco_Click);
            // 
            // chkRedValvet
            // 
            this.chkRedValvet.AutoSize = true;
            this.chkRedValvet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRedValvet.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkRedValvet.Location = new System.Drawing.Point(11, 32);
            this.chkRedValvet.Margin = new System.Windows.Forms.Padding(2);
            this.chkRedValvet.Name = "chkRedValvet";
            this.chkRedValvet.Size = new System.Drawing.Size(147, 21);
            this.chkRedValvet.TabIndex = 1;
            this.chkRedValvet.Text = "Red Valvet Cake";
            this.chkRedValvet.UseVisualStyleBackColor = true;
            this.chkRedValvet.CheckedChanged += new System.EventHandler(this.chkRedValvet_CheckedChanged);
            // 
            // txtBostonCream
            // 
            this.txtBostonCream.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBostonCream.Location = new System.Drawing.Point(206, 73);
            this.txtBostonCream.Margin = new System.Windows.Forms.Padding(2);
            this.txtBostonCream.Multiline = true;
            this.txtBostonCream.Name = "txtBostonCream";
            this.txtBostonCream.Size = new System.Drawing.Size(79, 25);
            this.txtBostonCream.TabIndex = 4;
            this.txtBostonCream.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBostonCream.Click += new System.EventHandler(this.txtBostonCream_Click);
            // 
            // txtBlackForestCake
            // 
            this.txtBlackForestCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBlackForestCake.Location = new System.Drawing.Point(206, 50);
            this.txtBlackForestCake.Margin = new System.Windows.Forms.Padding(2);
            this.txtBlackForestCake.Multiline = true;
            this.txtBlackForestCake.Name = "txtBlackForestCake";
            this.txtBlackForestCake.Size = new System.Drawing.Size(79, 25);
            this.txtBlackForestCake.TabIndex = 4;
            this.txtBlackForestCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBlackForestCake.Click += new System.EventHandler(this.txtBlackForestCake_Click);
            // 
            // chkKilburnChoco
            // 
            this.chkKilburnChoco.AutoSize = true;
            this.chkKilburnChoco.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkKilburnChoco.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkKilburnChoco.Location = new System.Drawing.Point(11, 125);
            this.chkKilburnChoco.Margin = new System.Windows.Forms.Padding(2);
            this.chkKilburnChoco.Name = "chkKilburnChoco";
            this.chkKilburnChoco.Size = new System.Drawing.Size(196, 21);
            this.chkKilburnChoco.TabIndex = 1;
            this.chkKilburnChoco.Text = "Kilburn Chocolate Cake";
            this.chkKilburnChoco.UseVisualStyleBackColor = true;
            this.chkKilburnChoco.CheckedChanged += new System.EventHandler(this.chkKilburnChoco_CheckedChanged);
            // 
            // txtRedValvetCake
            // 
            this.txtRedValvetCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRedValvetCake.Location = new System.Drawing.Point(206, 27);
            this.txtRedValvetCake.Margin = new System.Windows.Forms.Padding(2);
            this.txtRedValvetCake.Multiline = true;
            this.txtRedValvetCake.Name = "txtRedValvetCake";
            this.txtRedValvetCake.Size = new System.Drawing.Size(79, 25);
            this.txtRedValvetCake.TabIndex = 4;
            this.txtRedValvetCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRedValvetCake.Click += new System.EventHandler(this.txtRedValvetCake_Click);
            // 
            // chkBlackForest
            // 
            this.chkBlackForest.AutoSize = true;
            this.chkBlackForest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBlackForest.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkBlackForest.Location = new System.Drawing.Point(11, 55);
            this.chkBlackForest.Margin = new System.Windows.Forms.Padding(2);
            this.chkBlackForest.Name = "chkBlackForest";
            this.chkBlackForest.Size = new System.Drawing.Size(149, 21);
            this.chkBlackForest.TabIndex = 1;
            this.chkBlackForest.Text = "Blackforest Cake";
            this.chkBlackForest.UseVisualStyleBackColor = true;
            this.chkBlackForest.CheckedChanged += new System.EventHandler(this.chkBlackForest_CheckedChanged);
            // 
            // txtCoffeCake
            // 
            this.txtCoffeCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCoffeCake.Location = new System.Drawing.Point(206, 3);
            this.txtCoffeCake.Margin = new System.Windows.Forms.Padding(2);
            this.txtCoffeCake.Multiline = true;
            this.txtCoffeCake.Name = "txtCoffeCake";
            this.txtCoffeCake.Size = new System.Drawing.Size(79, 25);
            this.txtCoffeCake.TabIndex = 3;
            this.txtCoffeCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCoffeCake.Click += new System.EventHandler(this.txtCoffeCake_Click);
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.checkBox13.Location = new System.Drawing.Point(11, 102);
            this.checkBox13.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(189, 21);
            this.checkBox13.TabIndex = 1;
            this.checkBox13.Text = "Lagos Chocolate Cake";
            this.checkBox13.UseVisualStyleBackColor = true;
            this.checkBox13.CheckedChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // chkBostonCream
            // 
            this.chkBostonCream.AutoSize = true;
            this.chkBostonCream.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBostonCream.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkBostonCream.Location = new System.Drawing.Point(11, 79);
            this.chkBostonCream.Margin = new System.Windows.Forms.Padding(2);
            this.chkBostonCream.Name = "chkBostonCream";
            this.chkBostonCream.Size = new System.Drawing.Size(169, 21);
            this.chkBostonCream.TabIndex = 1;
            this.chkBostonCream.Text = "Boston Cream Cake";
            this.chkBostonCream.UseVisualStyleBackColor = true;
            this.chkBostonCream.CheckedChanged += new System.EventHandler(this.chkBostonCream_CheckedChanged);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel5.Controls.Add(this.lblTotal);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.lblTax);
            this.panel5.Controls.Add(this.lblSubTotal);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Location = new System.Drawing.Point(345, 288);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(333, 148);
            this.panel5.TabIndex = 1;
            // 
            // lblTotal
            // 
            this.lblTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTotal.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTotal.Location = new System.Drawing.Point(155, 98);
            this.lblTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(149, 29);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(7, 105);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 24);
            this.label11.TabIndex = 2;
            this.label11.Text = "Total";
            // 
            // lblTax
            // 
            this.lblTax.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTax.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTax.Location = new System.Drawing.Point(155, 31);
            this.lblTax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(149, 29);
            this.lblTax.TabIndex = 0;
            this.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSubTotal.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblSubTotal.Location = new System.Drawing.Point(155, 65);
            this.lblSubTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(149, 29);
            this.lblSubTotal.TabIndex = 1;
            this.lblSubTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(7, 38);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "Tax";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(7, 72);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 24);
            this.label10.TabIndex = 1;
            this.label10.Text = "SubTotal";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel6.Controls.Add(this.rtfReceipt);
            this.panel6.Controls.Add(this.toolStrip1);
            this.panel6.Location = new System.Drawing.Point(682, 80);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(279, 270);
            this.panel6.TabIndex = 1;
            // 
            // rtfReceipt
            // 
            this.rtfReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtfReceipt.Location = new System.Drawing.Point(2, 33);
            this.rtfReceipt.Margin = new System.Windows.Forms.Padding(2);
            this.rtfReceipt.Name = "rtfReceipt";
            this.rtfReceipt.Size = new System.Drawing.Size(273, 235);
            this.rtfReceipt.TabIndex = 5;
            this.rtfReceipt.Text = "";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.printToolStripButton,
            this.toolStripSeparator,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.toolStripSeparator1,
            this.helpToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(279, 31);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.newToolStripButton.Text = "&New";
            this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.openToolStripButton.Text = "&Open";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.saveToolStripButton.Text = "&Save";
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // printToolStripButton
            // 
            this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
            this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripButton.Name = "printToolStripButton";
            this.printToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.printToolStripButton.Text = "&Print";
            this.printToolStripButton.Click += new System.EventHandler(this.printToolStripButton_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 31);
            // 
            // cutToolStripButton
            // 
            this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
            this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripButton.Name = "cutToolStripButton";
            this.cutToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.cutToolStripButton.Text = "C&ut";
            this.cutToolStripButton.Click += new System.EventHandler(this.cutToolStripButton_Click);
            // 
            // copyToolStripButton
            // 
            this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
            this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripButton.Name = "copyToolStripButton";
            this.copyToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.copyToolStripButton.Text = "&Copy";
            this.copyToolStripButton.Click += new System.EventHandler(this.copyToolStripButton_Click);
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.pasteToolStripButton.Text = "&Paste";
            this.pasteToolStripButton.Click += new System.EventHandler(this.pasteToolStripButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // helpToolStripButton
            // 
            this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
            this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.helpToolStripButton.Name = "helpToolStripButton";
            this.helpToolStripButton.Size = new System.Drawing.Size(28, 28);
            this.helpToolStripButton.Text = "He&lp";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel7.Controls.Add(this.btnExit);
            this.panel7.Controls.Add(this.button3);
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.button1);
            this.panel7.Location = new System.Drawing.Point(682, 354);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(279, 82);
            this.panel7.TabIndex = 1;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExit.Location = new System.Drawing.Point(210, 31);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(64, 29);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.Location = new System.Drawing.Point(142, 31);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 29);
            this.button3.TabIndex = 0;
            this.button3.Text = "Reset";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(76, 31);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(62, 29);
            this.button2.TabIndex = 0;
            this.button2.Text = "Receipt";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(8, 31);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "Total";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 437);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cafe Billing System";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtLatte;
        private System.Windows.Forms.CheckBox chkChineseTea;
        private System.Windows.Forms.CheckBox chkMilkTea;
        private System.Windows.Forms.CheckBox chkAfricanCoffe;
        private System.Windows.Forms.CheckBox chkCappucino;
        private System.Windows.Forms.CheckBox chkValeCoffee;
        private System.Windows.Forms.CheckBox chkMocha;
        private System.Windows.Forms.CheckBox chkEspresso;
        private System.Windows.Forms.CheckBox chkLatte;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSvcCharge;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCakeCost;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblDrinkCost;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.CheckBox chkRainbowCake;
        private System.Windows.Forms.CheckBox chkCoffe;
        private System.Windows.Forms.CheckBox chkCheese;
        private System.Windows.Forms.CheckBox chkRedValvet;
        private System.Windows.Forms.CheckBox chkKilburnChoco;
        private System.Windows.Forms.CheckBox chkBlackForest;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox chkBostonCream;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtChineseTea;
        private System.Windows.Forms.TextBox txtMilkTea;
        private System.Windows.Forms.TextBox txtAfricanCoffee;
        private System.Windows.Forms.TextBox txtCappu;
        private System.Windows.Forms.TextBox txtValeCoffee;
        private System.Windows.Forms.TextBox txtMocha;
        private System.Windows.Forms.TextBox txtEspresso;
        private System.Windows.Forms.TextBox txtRainbowCake;
        private System.Windows.Forms.TextBox txtCheeseCake;
        private System.Windows.Forms.TextBox txtKillburnChoco;
        private System.Windows.Forms.TextBox txtLagosChoco;
        private System.Windows.Forms.TextBox txtBostonCream;
        private System.Windows.Forms.TextBox txtBlackForestCake;
        private System.Windows.Forms.TextBox txtRedValvetCake;
        private System.Windows.Forms.TextBox txtCoffeCake;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton helpToolStripButton;
        private System.Windows.Forms.Timer timer1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.RichTextBox rtfReceipt;
    }
}

